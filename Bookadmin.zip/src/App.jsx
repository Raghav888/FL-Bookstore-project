import { useState } from "react";
import DataTable from "./components/DataTable";
import SearchAppBar from "./components/SearchAppBar";
import { useTableData, useSellerTableData } from "./httpClients/queries";

function App() {

  // state var
  const [searchInput, setSearchInput] = useState();
  
  const [showSellerData, setSellerData] = useState(false);

  // get seller data or admin data based on condition
  const { data } = showSellerData ? useSellerTableData() : useTableData();
  // set toggle button state
  const updateData = () => setSellerData(!showSellerData);

  // change state when user type in search bar
  const updateSearch = (newString) => setSearchInput(newString);

  // filter data based on user input
  const filteredData = () => {
    if (!searchInput) {
      return data;
    }
    const newData = data.filter((obj) =>
      obj.name.toLowerCase().includes(searchInput.toLowerCase())
    );
    return newData;
  };

  return (
    <>
      <SearchAppBar updateData={updateData} updateSearch={updateSearch} showSellerData={showSellerData} />
        <div className="dataTable">
          <DataTable tableData={filteredData()} />
        </div>
    </>
  );
}

export default App;
