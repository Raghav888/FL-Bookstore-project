import { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import { useAddData } from "../httpClients/queries";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function InputModal() {
  // state var
  const [open, setOpen] = useState(false);
  const [productName, setProductName] = useState();
  const [productQuantity, setProductQuantity] = useState();

  // get data from react query
  const { mutate } = useAddData();

  // method to execute on save bytton click
  const onSave = () => {
    mutate({
      name: productName,
      quantity: productQuantity,
    });
    setOpen(false);
    setProductName();
    setProductQuantity();
  };

  return (
    <div>
      <Button variant="contained" onClick={() => setOpen(true)}>
        New Entry
      </Button>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div>
            <h3>Enter New Product</h3>
          </div>
          <div className="space-bottom">
            <TextField
              id="outlined-basic"
              label="Bookname"
              variant="outlined"
              required
              onChange={(e) => setProductName(e.target.value)}
            />
          </div>
          <div className="space-bottom">
            <TextField
              type="number"
              id="outlined-basic"
              label="Quantity"
              variant="outlined"
              required
              onChange={(e) => setProductQuantity(e.target.value)}
            />
          </div>
          <div className="space-bottom">
            <Button onClick={() => onSave()} variant="contained">
              Save
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  );
}
