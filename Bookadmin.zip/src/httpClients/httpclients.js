import axios from "axios";

// method to get table data
export const getTableData = async () => {
  const response = await axios.get(
    "http://sku-warehouse-3.us-east-1.elasticbeanstalk.com/items"
  );
  return response?.data?.data;
};

// method to add new data
export const postNewData = async (payload) => {
  try {
    await axios.post('http://sku-warehouse-3.us-east-1.elasticbeanstalk.com/items', payload);
  } catch (error) {
    console.error('Error posting data:', error);
  }
};

// method to get seller side data
export const getSellerTableData = async () => {
  const response = await axios.get(
    "http://sku-admin.us-east-1.elasticbeanstalk.com/items"
  );
  return response?.data?.data;
};