import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getTableData, getSellerTableData, postNewData } from "./httpclients";

//react query code

// to get table data
export const useTableData = () =>
  useQuery({
    queryKey: ["getTableData"],
    queryFn: () => getTableData(),
    refetchInterval:false,
    staleTime: 100000,
  });


// to add new entry
export const useAddData = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: postNewData,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["getTableData"] });
    },
  });
};


// to get seller side data
export const useSellerTableData = () =>
  useQuery({
    queryKey: ["getSellerTableData"],
    queryFn: () => getSellerTableData(),
    refetchInterval:false,
    staleTime: 100000,
  });