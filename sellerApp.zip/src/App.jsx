import { useState } from "react";
import DataTable from "./components/DataTable";
import SearchAppBar from "./components/SearchAppBar";
import { useTableData, useStoreTableData } from "./httpClients/queries";

function App() {
  // state var 
  const [searchInput, setSearchInput] = useState();
  const [showStoreData, setStoreData] = useState(false);

  // update when toggle button is clicked
  const updateData = () => setStoreData(!showStoreData);

  // to set when user input changes in search box
  const updateSearch = (newString) => setSearchInput(newString);

  // to get data based on condition
  const { data } = !showStoreData ? useTableData() : useStoreTableData();

  // filter data based on user input
  const filteredData = () => {
    if (!searchInput) {
      return data;
    }
    const newData = data.filter((obj) =>
      obj.name.toLowerCase().includes(searchInput.toLowerCase())
    );
    return newData;
  };

  return (
    <>
      <SearchAppBar updateData={updateData} updateSearch={updateSearch} />
      <div className="dataTable">
        <DataTable showStoreData={showStoreData} tableData={filteredData()} />
      </div>
    </>
  );
}

export default App;
