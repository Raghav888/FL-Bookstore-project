import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import InputModal from "./InputModal";
import { useState } from "react";

export default function DataTable(props) {

  // state var to store double click event data
  const [data, setData] = useState({ flag: false });

  // set data on double click on cell
  const handleDoubleClick = (id, name, quantity) => {
    if (id && !props.showStoreData) {
      setData({ flag: true, id, name, quantity });
    }
  };

  return (
    <>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <TableCell align="left">SKU</TableCell>
              <TableCell>Product Name</TableCell>
              <TableCell align="left">Quantity</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(props?.tableData || []).map((row) => (
              <TableRow
                key={row.id}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell align="left">{row.id.substring(0, 5)}</TableCell>
                <TableCell
                  onDoubleClick={() =>
                    handleDoubleClick(row.id, row.name, row.quantity)
                  }
                  component="th"
                  scope="row"
                >
                  {row.name}
                </TableCell>
                <TableCell
                  onDoubleClick={() =>
                    handleDoubleClick(row.id, row.name, row.quantity)
                  }
                  align="left"
                >
                  {row.quantity}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <InputModal data={data} />
    </>
  );
}
