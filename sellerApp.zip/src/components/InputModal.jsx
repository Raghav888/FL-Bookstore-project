import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import { useUpdateData } from "../httpClients/queries";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function InputModal(props) {

  // state var to store data in input field
  const [open, setOpen] = useState(props?.data?.flag);
  const [productName, setProductName] = useState(props?.data?.name || "");
  const [productQuantity, setProductQuantity] = useState(
    props?.data?.quantity || ""
  );

  // usememo hook, to store data in state var when props changes
  useMemo(() => {
    setOpen(props?.data?.flag);
    setProductName(props?.data?.name);
    setProductQuantity(props?.data?.quantity);
  }, [props?.data]);

  // mutate for put request
  const { mutate } = useUpdateData();

  // method to execute when click on save button
  const onSave = () => {
    mutate({id:props.data.id,
      name: productName,
      quantity: productQuantity,
    });
    setOpen(false);
    setProductName();
    setProductQuantity();
  };

  return (
    <div>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div>
            <h3>Enter New Product</h3>
          </div>
          <div className="space-bottom">
            <TextField
              id="outlined-basic"
              label="Bookname"
              variant="outlined"
              required
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
            />
          </div>
          <div className="space-bottom">
            <TextField
              type="number"
              id="outlined-basic"
              label="Quantity"
              variant="outlined"
              required
              value={productQuantity}
              onChange={(e) => setProductQuantity(e.target.value)}
            />
          </div>
          <div className="space-bottom">
            <Button onClick={() => onSave()} variant="contained">
              Save
            </Button>
          </div>
        </Box>
      </Modal>
    </div>
  );
}
