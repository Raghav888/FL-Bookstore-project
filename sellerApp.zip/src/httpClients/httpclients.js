import axios from "axios";

// api calls

// to get seller data
export const getTableData = async () => {
  const response = await axios.get(
    "http://sku-admin.us-east-1.elasticbeanstalk.com/items"
  );
  return response?.data?.data;
};

// to update existing data
export const updateQuantity = async (payload) => {
  await axios.put(
    `http://sku-admin.us-east-1.elasticbeanstalk.com/item/${payload.id}`,
    { name: payload.name, quantity: payload.quantity }
  );
};


// to get admin data
export const getStoreTableData = async () => {
  const response = await axios.get(
    "http://sku-warehouse-3.us-east-1.elasticbeanstalk.com/items"
  );
  return response?.data?.data;
};
