import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getTableData, updateQuantity, getStoreTableData } from "./httpclients";


// react query

// to get seller data
export const useTableData = () =>
  useQuery({
    queryKey: ["getTableData"],
    queryFn: () => getTableData(),
    refetchInterval:false,
    staleTime: 10000,
  });


// to update existing seller data
export const useUpdateData = () => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: updateQuantity,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["getTableData"] });
    },
  });
};


// to get admin data
export const useStoreTableData = () =>
  useQuery({
    queryKey: ["getStoreTableData"],
    queryFn: () => getStoreTableData(),
    refetchInterval:false,
    staleTime: 10000,
  });